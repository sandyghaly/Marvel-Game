package engine;

import java.util.ArrayList;

import model.world.Champion;

public interface PlayerListener {
	

	void onTeamUpdated();
	void OnleaderUpdated();

}
