package Controller;

import java.awt.BorderLayout;

import javax.swing.JComboBox;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.abilities.Ability;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Direction;
import model.world.Hero;
import model.world.Villain;
import engine.Game;
import engine.Player;
import engine.PlayerListener;
import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import Gameview.View;

public class Controller implements ActionListener, PlayerListener, MouseListener{
	private Game Game;
	private View View;
	private ArrayList<JButton> buttons;
	private ArrayList<JButton> FPbuttons;
	private ArrayList<JButton> SPbuttons;
	private ArrayList<JButton> TObuttons;
	private ArrayList<JButton> CA1buttons;
	private ArrayList<JButton> CA1buttonsDirection;
	private ArrayList<JButton> CA1buttonsLocation;
	
	private JButton start;
	private int counterTeam1=0;
	private int counterTeam2=0;
	private int counterLeaders=0;
	private JButton Next;
	private int counter2=0;
	private JLabel n3;
	private boolean flag= false;
	private JButton test;
	private JButton Leaderability1;
	private JButton Leaderability2;
	private JButton move;
	private JButton up;
	private JButton down;
	private JButton right;
	private JButton left;
	private JButton attackup;
	private JButton attackdown;
	private JButton attackright;
	private JButton attackleft;
	private JButton CastA;
	private JButton CastUP;
	private JButton CastDOWN;
	private JButton CastRIGHT;
	private JButton CastLEFT;
	private JButton CastLOC;
	private JButton endturn;
	private JLabel currentChamp;
	private boolean CastAflag= false;
	private boolean CastAflagUP= false;
	private boolean CastAflagDOWN= false;
	private boolean CastAflagRIGHT= false;
	private boolean CastAflagLEFT= false;
	private boolean CastLOCflag= false;
	private boolean flag2= false;
//	private JTextField x;
//	private JTextField y;
	int x;
	int y;
	
	//private List<JComboBox> dropdown;

	public Controller() throws IOException {
		//dropdown= new List<JComboBox>();
//		 x= new JTextField(); 
//		 y= new JTextField();
		
		currentChamp= new JLabel();
		buttons = new ArrayList<JButton>();
		FPbuttons = new ArrayList<JButton>();
		SPbuttons = new ArrayList<JButton>();
		TObuttons = new ArrayList<JButton>();
		CA1buttons= new ArrayList<JButton>();
		CA1buttonsDirection= new ArrayList<JButton>();
		CA1buttonsLocation= new ArrayList<JButton>();
		
		
		move = new JButton("Move");
		up = new JButton("Move.UP");
		up.setBackground(Color.GRAY);
		down = new JButton("Move.DOWN");
		down.setBackground(Color.GRAY);
		right = new JButton("Move.RIGHT");
		right.setBackground(Color.GRAY);
		left = new JButton("Move.LEFT");
		left.setBackground(Color.GRAY);
		attackup = new JButton("Attack.UP");
		attackup.setBackground(Color.GREEN);
		attackdown= new JButton("Attack.DOWN");
		attackdown.setBackground(Color.GREEN);
		attackright = new JButton("Attack.RIGHT");
		attackright.setBackground(Color.GREEN);
		attackleft = new JButton("Attack.LEFT");
		attackleft.setBackground(Color.GREEN);
		endturn = new JButton("EndTurn");
		CastA = new JButton("CastABility(Ability)");
		CastA.setBackground(Color.MAGENTA);
		CastUP= new JButton("CastABility.UP");
		CastUP.setBackground(Color.MAGENTA);
		CastDOWN= new JButton("CastABility.DOWN");
		CastDOWN.setBackground(Color.MAGENTA);
		CastRIGHT= new JButton("CastABility.RIGHT");
		CastRIGHT.setBackground(Color.MAGENTA);
		CastLEFT= new JButton("CastABility.LEFT");
		CastLEFT.setBackground(Color.MAGENTA);
		CastLOC= new JButton("CastABility.location");
		CastLOC.setBackground(Color.MAGENTA);
		
		View= new View();
		start = new JButton("Start");
		start.addActionListener(this);
		View.getP1().add(start);
	
		Player f= new Player(View.getName1().getText());
		Player s= new Player(View.getName2().getText());
		Game = new Game(f,s);
		engine.Game.loadAbilities("Abilities.csv");
		engine.Game.loadChampions("Champions.csv");
		Game.getFirstPlayer().setListener(this);
		Game.getSecondPlayer().setListener(this);
		
		Next = new JButton("Next");
		test = new JButton("test");
		Leaderability1= new JButton("First player leader ability");
		Leaderability1.setBackground(Color.lightGray);
   		
   		Leaderability2= new JButton("Second player leader ability");
   		Leaderability2.setBackground(Color.lightGray);
		
		View.getTeams().add(Next);
		Next.addActionListener(this);
		n3= new JLabel("choose yor leader \n");
		View.getTeams().add(n3);
		//currentChamp.setText(Game.getCurrentChampion().toString());
		
}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new Controller();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		JButton b= (JButton) e.getSource();
///////////////////////////start action//////////////////////////////////////
		
		if(b==start){
	
			View.remove(View.getP1());
			
			View.add(View.getP2());
			for(int i=0; i< engine.Game.getAvailableChampions().size(); i++){
				
				JButton temp = new JButton();
				temp.addMouseListener(this );
				temp.addActionListener(this);
				buttons.add(temp);
				Champion c= engine.Game.getAvailableChampions().get(i);
				temp.setText(c.getName());
				View.getP2().add(temp);
				View.revalidate();
				View.repaint();
				temp.setToolTipText(c.toString());
				View.revalidate();
				View.repaint();
				
			}		
			
		
		}
          

//////////////////////////add team action////////////////////////////////////		
		else if( counterTeam1<3 && helper(b) ){
			 JLabel n1= new JLabel("First Player team \n");
			
			 
			int r= buttons.indexOf(b);
			Champion c= engine.Game.getAvailableChampions().get(r);
			if(Game.getFirstPlayer().getTeam().size()<3 && !(Game.getFirstPlayer().getTeam().contains(c))
					){
				b.setEnabled(false);
				Game.getFirstPlayer().getTeam().add(c);
				//Game.getFirstPlayer().updateteam();
				
				counterTeam1++;
				JButton temp = new JButton();
				temp.addActionListener(this);
				//buttons.add(temp);
				FPbuttons.add(temp);
				temp.setText(c.getName());
				View.getTeams().add(n1);
				View.getTeams().add(temp);
				temp.setToolTipText(c.toString());
				
				View.revalidate();
				View.repaint();
				}
			
		}
		else if( counterTeam2<3  && helper(b) &&  counterTeam1>=3 ){
			 JLabel n2= new JLabel("Second Player team \n");
			int r= buttons.indexOf(b);
			Champion c= engine.Game.getAvailableChampions().get(r);
		 if(Game.getSecondPlayer().getTeam().size()<3 && !(Game.getSecondPlayer().getTeam().contains(c) &&
					Game.getFirstPlayer().getTeam().size()==3 ) 
					){
			 b.setEnabled(false);
				Game.getSecondPlayer().getTeam().add(c);
				
				
				counterTeam2++;
				JButton temp = new JButton();
				temp.addActionListener(this);
				
				SPbuttons.add(temp);
				temp.setText(c.getName());
				View.getTeams().add(n2);
				View.getTeams().add(temp);
				temp.setToolTipText(c.toString());
				
				View.revalidate();
				View.repaint();
				}
			
			
			
		}
////////////////////////////next////////////////////////////////////////////////		////////////////////////
		
		  else if(b==Next){
/////////////////			  
            View.remove(View.getP2());
            View.remove(View.getTeams()); 
            View.add(View.getP3(),BorderLayout.CENTER );
            View.add(View.getfPlayer(),BorderLayout.NORTH);
            View.add(View.getsPlayer(), BorderLayout.SOUTH);
            View.add(View.getP4(), BorderLayout.EAST);
            View.add(View.getP5(),BorderLayout.WEST );
           
/////////////////   
            refreshNorth();
            refreshSouth();
            
//            String s = View.getName1().getText() +" team: ";
//            JLabel t1= new JLabel();
//            t1.setText(s);
//            View.getfPlayer().add(t1);
//            for(int i=0; i<Game.getFirstPlayer().getTeam().size();i++){
//            	
//         	   Champion c= Game.getFirstPlayer().getTeam().get(i);
//         	   JButton temp= new JButton();
//         	 
//         	   temp.setText(c.getName());
//         	   View.getfPlayer().add(temp);
//         	  temp.setToolTipText(c.toString());
//         	  
//         	   View.revalidate();
//               View.repaint();
//           }
//          
           
            
//            String s2 =  View.getName2().getText() +" team: ";
//            JLabel t= new JLabel();
//            t.setText(s2);
//            View.getsPlayer().add(t);
//          
//            for(int i=0; i<Game.getSecondPlayer().getTeam().size();i++){
//            	
//         	   Champion c= Game.getSecondPlayer().getTeam().get(i);
////         	   s2+= c.getName() + " ,";
//         	  JButton temp= new JButton(c.getName());
//        	   View.getsPlayer().add(temp);
//        	   temp.setToolTipText(c.toString());
//         	  
//         	   View.revalidate();
//               View.repaint();
//           }
           // View.getsPlayer().setText(s2);
 /////////////////////////////east          
              View.getP4().add(Leaderability1);
              View.getP4().add(Leaderability2);
              Leaderability1.addActionListener(this);
              Leaderability2.addActionListener(this);
              View.revalidate();
              View.repaint();
//              View.getP4().add(move);
//              move.addActionListener(this);
              View.getP4().add(up);
  			View.getP4().add(down);
  			View.getP4().add(left);
  			View.getP4().add(right);
  			up.addActionListener(this);
  			down.addActionListener(this);
  			right.addActionListener(this);
  			left.addActionListener(this);
  			

              View.getP4().add(attackup);
              attackup.addActionListener(this);
              View.getP4().add(attackdown);
              attackdown.addActionListener(this);
              View.getP4().add(attackright);
              attackright.addActionListener(this);
              View.getP4().add(attackleft);
              attackleft.addActionListener(this);
              View.getP4().add(endturn);
              endturn.addActionListener(this);
              View.getP4().add(CastA);
              CastA.addActionListener(this);
              View.getP4().add(CastUP);
              CastUP.addActionListener(this);
             
              View.getP4().add(CastDOWN);
              CastDOWN.addActionListener(this);

      		
      	      View.getP4().add(CastRIGHT);
      	      CastRIGHT.addActionListener(this);
      	
      		  View.getP4().add(CastLEFT);
      		  CastLEFT.addActionListener(this);
      		  
      		  View.getP4().add(CastLOC);
      		  CastLOC.addActionListener(this);
     		
  		
              
//////////////////////////////////Board///////////////////////////////////              
              View.add(View.getP3());
              Game.placeChampions();
              refreshboard();
            
              View.revalidate();
              View.repaint();
////////////////////////////////////west
             
              Game.prepareChampionTurns();    
//              currentChamp.setText(Game.getCurrentChampion().toString());
// 	         View.getP5().add(currentChamp);
              PQ();
        
            
            
                }
////////////////////////move/////////////////////////////////////////////////
//		if(b==move){
//			up.setVisible(true);
//  			down.setVisible(true);
//  			right.setVisible(true);
//  			left.setVisible(true);
//			
//            View.repaint();
//            
//			
//		}
///////////////////////cast A Location//////////////////////////////////
		if(b==CastLOC){
			
//			
			Champion c= Game.getCurrentChampion();
			for(int i=0;i<c.getAbilities().size();i++){
				JButton temp= new JButton(c.getAbilities().get(i).getName());
				 temp.setToolTipText(c.getAbilities().toString());
				temp.addActionListener(this);
				temp.setBackground(Color.ORANGE);
				View.getP4().add(temp);
				CA1buttonsLocation.add(temp);
				View.revalidate();
	            View.repaint();
	            
			}
			View.revalidate();
            View.repaint();
            x= Integer.parseInt(JOptionPane.showInputDialog("enetr x"));
            y= Integer.parseInt(JOptionPane.showInputDialog("enetr y"));
            if(x>5 || y>5){
            	 x= Integer.parseInt(JOptionPane.showInputDialog("enetr valid x"));
                 y= Integer.parseInt(JOptionPane.showInputDialog("enetr valid y"));
	            	
	            }

            CastLOCflag=true;
		}
////////////
		if(CastLOCflag==true){
			System.out.println("Location" + CA1buttonsLocation.size());

			if(CA1buttonsLocation.contains(b)){
				int i= CA1buttonsLocation.indexOf(b);
				Ability a= Game.getCurrentChampion().getAbilities().get(i);
				 if(x>5 || y>5){
					 JOptionPane.showMessageDialog(null, "InvalidTargetException");
		            	
		            }
				
				try {
					Game.castAbility(a, x, y);
				} catch (NotEnoughResourcesException e1) {
					 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				} catch (AbilityUseException e1) {
					 JOptionPane.showMessageDialog(null, "AbilityUseException");
				} catch (InvalidTargetException e1) {
					 JOptionPane.showMessageDialog(null, "InvalidTargetException");
				} catch (CloneNotSupportedException e1) {
					 JOptionPane.showMessageDialog(null, "CloneNotSupportedException");
				}
				
				
		
				  for(int x=CA1buttonsLocation.size()-1; x>=0;x--){
						JButton temp= CA1buttonsLocation.get(x);
						
						View.getP4().remove(temp);
						CA1buttonsLocation.remove(x);
						
					}
				
				 
				View.revalidate();
	            View.repaint();
			}

			
			
			 
			
			
		}
///////////////////////cast A directionLEFT//////////////////////////////////
		if(b==CastLEFT){
			Champion c= Game.getCurrentChampion();
			for(int i=0;i<c.getAbilities().size();i++){
				Ability a= c.getAbilities().get(i);
				JButton temp= new JButton(c.getAbilities().get(i).getName());
				if( a instanceof HealingAbility){
					int h=((HealingAbility) a).getHealAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Healing Amount" + h);
					
				}
				if(a instanceof DamagingAbility){
					int d= ((DamagingAbility)a).getDamageAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							" \n Damage Amount" + d);
				}
				if(a instanceof CrowdControlAbility){
					Effect effect= ((CrowdControlAbility)a).getEffect();
					temp.setToolTipText(c.getAbilities().toString() +
							"Effect" + effect);
					
				}
				
				temp.addActionListener(this);
				
				temp.setBackground(Color.ORANGE);
				View.getP4().add(temp);
				CA1buttonsDirection.add(temp);
				View.revalidate();
	            View.repaint();
	            
			}
			System.out.println("merna direction");
			CastAflagLEFT=true;
			
		}
////////////
		 if(CastAflagLEFT==true){
				
				if(CA1buttonsDirection.contains(b)){
					int i= CA1buttonsDirection.indexOf(b);
					Ability a= Game.getCurrentChampion().getAbilities().get(i);
					try {
						Game.castAbility(a, Direction.LEFT);
					} catch (NotEnoughResourcesException e2) {
						 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
					} catch (AbilityUseException e2) {
						 JOptionPane.showMessageDialog(null, "AbilityUseException");
					} catch (CloneNotSupportedException e2) {
						 JOptionPane.showMessageDialog(null, "CloneNotSupportedException");
					}
					
			
					  for(int x=CA1buttonsDirection.size()-1; x>=0;x--){
							JButton temp= CA1buttonsDirection.get(x);
							
							View.getP4().remove(temp);
							CA1buttonsDirection.remove(x);
							
						}
					
					
					View.revalidate();
		            View.repaint();
				}

				
				
			}
 
///////////////////////cast A directionRIGHT//////////////////////////////////
		if(b==CastRIGHT){
			Champion c= Game.getCurrentChampion();
			for(int i=0;i<c.getAbilities().size();i++){
				Ability a= c.getAbilities().get(i);
				JButton temp= new JButton(c.getAbilities().get(i).getName());
				if( a instanceof HealingAbility){
					int h=((HealingAbility) a).getHealAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Healing Amount" + h);
					
				}
				if(a instanceof DamagingAbility){
					int d= ((DamagingAbility)a).getDamageAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Damage Amount" + d);
				}
				if(a instanceof CrowdControlAbility){
					Effect effect= ((CrowdControlAbility)a).getEffect();
					temp.setToolTipText(c.getAbilities().toString() +
							"Effect" + effect);
					
				}
				
				temp.addActionListener(this);
				
				temp.setBackground(Color.ORANGE);
				View.getP4().add(temp);
				CA1buttonsDirection.add(temp);
				View.revalidate();
	            View.repaint();
	            
			}
			System.out.println("merna direction");
			CastAflagRIGHT=true;
			
		}
//////////////
		 if(CastAflagRIGHT==true){
				
				if(CA1buttonsDirection.contains(b)){
					int i= CA1buttonsDirection.indexOf(b);
					Ability a= Game.getCurrentChampion().getAbilities().get(i);
					try {
						Game.castAbility(a, Direction.RIGHT);
					} catch (NotEnoughResourcesException e2) {
						 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
					} catch (AbilityUseException e2) {
						 JOptionPane.showMessageDialog(null, "AbilityUseException");
					} catch (CloneNotSupportedException e2) {
						 JOptionPane.showMessageDialog(null, "CloneNotSupportedException");
					}
					
			
					  for(int x=CA1buttonsDirection.size()-1; x>=0;x--){
							JButton temp= CA1buttonsDirection.get(x);
							
							View.getP4().remove(temp);
							CA1buttonsDirection.remove(x);
							
						}
					
					
					View.revalidate();
		            View.repaint();
				}

				
				
			}
		
///////////////////////cast A directionDOWN//////////////////////////////////
		if(b==CastDOWN){
			Champion c= Game.getCurrentChampion();
			for(int i=0;i<c.getAbilities().size();i++){
				Ability a= c.getAbilities().get(i);
				JButton temp= new JButton(c.getAbilities().get(i).getName());
				if( a instanceof HealingAbility){
					int h=((HealingAbility) a).getHealAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Healing Amount" + h);
					
				}
				if(a instanceof DamagingAbility){
					int d= ((DamagingAbility)a).getDamageAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Damage Amount" + d);
				}
				if(a instanceof CrowdControlAbility){
					Effect effect= ((CrowdControlAbility)a).getEffect();
					temp.setToolTipText(c.getAbilities().toString() +
							"Effect" + effect);
					
				}
				
				temp.addActionListener(this);
				
				temp.setBackground(Color.ORANGE);
				View.getP4().add(temp);
				CA1buttonsDirection.add(temp);
				View.revalidate();
	            View.repaint();
	            
			}
			System.out.println("merna direction");
			CastAflagDOWN=true;
			
		}
///////////
          if(CastAflagDOWN==true){
			
			if(CA1buttonsDirection.contains(b)){
				int i= CA1buttonsDirection.indexOf(b);
				Ability a= Game.getCurrentChampion().getAbilities().get(i);
				try {
					Game.castAbility(a, Direction.DOWN);
				} catch (NotEnoughResourcesException e2) {
					 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				} catch (AbilityUseException e2) {
					 JOptionPane.showMessageDialog(null, "AbilityUseException");
				} catch (CloneNotSupportedException e2) {
					 JOptionPane.showMessageDialog(null, "CloneNotSupportedException");
				}
				
		
				  for(int x=CA1buttonsDirection.size()-1; x>=0;x--){
						JButton temp= CA1buttonsDirection.get(x);
						
						View.getP4().remove(temp);
						CA1buttonsDirection.remove(x);
						
					}
				
				
				View.revalidate();
	            View.repaint();
			}

			
			
		}
		
///////////////////////cast A directionUP//////////////////////////////////
		if(b==CastUP){
			Champion c= Game.getCurrentChampion();
			for(int i=0;i<c.getAbilities().size();i++){
				Ability a= c.getAbilities().get(i);
				JButton temp= new JButton(c.getAbilities().get(i).getName());
				if( a instanceof HealingAbility){
					int h=((HealingAbility) a).getHealAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Healing Amount" + h);
					
				}
				if(a instanceof DamagingAbility){
					int d= ((DamagingAbility)a).getDamageAmount();
					temp.setToolTipText(c.getAbilities().toString() +
							"Damage Amount" + d);
				}
				if(a instanceof CrowdControlAbility){
					Effect effect= ((CrowdControlAbility)a).getEffect();
					temp.setToolTipText(c.getAbilities().toString() +
							"Effect" + effect);
					
				}
				
				temp.addActionListener(this);
				
				temp.setBackground(Color.ORANGE);
				View.getP4().add(temp);
				CA1buttonsDirection.add(temp);
				View.revalidate();
	            View.repaint();
	            
			}
			System.out.println("merna direction");
			CastAflagUP=true;
			
		}
////////////////
		if(CastAflagUP==true){
			
			if(CA1buttonsDirection.contains(b)){
				int i= CA1buttonsDirection.indexOf(b);
				Ability a= Game.getCurrentChampion().getAbilities().get(i);
				try {
					Game.castAbility(a, Direction.UP);
				} catch (NotEnoughResourcesException e2) {
					 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				} catch (AbilityUseException e2) {
					 JOptionPane.showMessageDialog(null, "AbilityUseException");
				} catch (CloneNotSupportedException e2) {
					 JOptionPane.showMessageDialog(null, "CloneNotSupportedException");
				}
				
		
				  for(int x=CA1buttonsDirection.size()-1; x>=0;x--){
						JButton temp= CA1buttonsDirection.get(x);
						
						View.getP4().remove(temp);
						CA1buttonsDirection.remove(x);
						
					}
				
				
				View.revalidate();
	            View.repaint();
			}

			
			
		}
//////////////////////CastA//////////////////////////////////////////////
		if(b==CastA ){
			
			Champion c= Game.getCurrentChampion();
			for(int i=0;i<c.getAbilities().size();i++){
				JButton temp= new JButton(c.getAbilities().get(i).getName());
				temp.addActionListener(this);
				 temp.setToolTipText(c.getAbilities().toString());
				View.getP4().add(temp);
				temp.setBackground(Color.ORANGE);
				CA1buttons.add(temp);
				View.revalidate();
	            View.repaint();
	            
			}
			System.out.println("merna");
			CastAflag=true;
			
		}
////////////////////
		if(CastAflag==true){
			System.out.println("Sandy");
			
			if(CA1buttons.contains(b)){
				int i= CA1buttons.indexOf(b);
				Ability a= Game.getCurrentChampion().getAbilities().get(i);
				try {
					Game.castAbility(a);
				} catch (NotEnoughResourcesException e1) {
					 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				
				} catch (AbilityUseException e1) {
					 JOptionPane.showMessageDialog(null, "AbilityUseException");
					
				} catch (CloneNotSupportedException e1) {
					 JOptionPane.showMessageDialog(null, "CloneNotSupportedException");
					
				}
				  for(int x=CA1buttons.size()-1; x>=0;x--){
						JButton temp= CA1buttons.get(x);
						
						View.getP4().remove(temp);
						CA1buttons.remove(x);
						
					}
				
				
				View.revalidate();
	            View.repaint();
			}

		}
	

			 if( FPbuttons.contains(b)&& 
					 Game.getFirstPlayer().getLeader()==null){
				 int r= FPbuttons.indexOf(b);
				Champion c= Game.getFirstPlayer().getTeam().get(r);
			
		}
		
//////////////////////end turn////////////////////////////////////////////
		if(b==endturn){
			
			Game.endTurn();
			if(Game.getTurnOrder().isEmpty()){
				Game.prepareChampionTurns();
			}
			View.getP5().removeAll();
			PQ();
			if(Game.checkGameOver()==Game.getFirstPlayer()){
				 JOptionPane.showMessageDialog(null, "WINNER WINNER KFC DINNER BOX FirstPlayer");
				 View.dispose();
				
			}
			if(Game.checkGameOver()==Game.getSecondPlayer()){
				 JOptionPane.showMessageDialog(null, "WINNER WINNER KFC DINNER BOX SecondPlayer");
				 View.dispose();
			}
			
			View.getfPlayer().removeAll();
			refreshNorth();
			View.getsPlayer().removeAll();
			refreshSouth();
			
			View.revalidate();
            View.repaint();
            System.out.println("CAi size11 " + CA1buttons.size());
            for(int i=CA1buttons.size()-1; i>=0;i--){
				JButton temp= CA1buttons.get(i);
				
				View.getP4().remove(temp);
				CA1buttons.remove(i);
				
			}
            
           
            CastAflag=false;
			System.out.println("CAi size " + CA1buttons.size());
			View.revalidate();
            View.repaint();
		}
	
		
////////////////////////////attack///////////////////////////////////////////
		if(b==attackup){
			try {
				Game.attack(Direction.UP);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
			} catch (ChampionDisarmedException e1) {
				 JOptionPane.showMessageDialog(null, "ChampionDisarmedException");
			} catch (InvalidTargetException e1) {
				 JOptionPane.showMessageDialog(null, "InvalidTargetException");
			}
			View.getP3().removeAll();
			refreshboard();
			
		}
/////////////////////////attack DOWN/////////////////////////////////////////
		if(b==attackdown){
			try {
				Game.attack(Direction.DOWN);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
			} catch (ChampionDisarmedException e1) {
				 JOptionPane.showMessageDialog(null, "ChampionDisarmedException");
			} catch (InvalidTargetException e1) {
				 JOptionPane.showMessageDialog(null, "InvalidTargetException");
			}
			View.getP3().removeAll();
			refreshboard();
			View.revalidate();
            View.repaint();
			
		}
//////////////////////////attack left////////////////////////////////////////
		if(b==attackright){
			try {
				Game.attack(Direction.LEFT);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
			} catch (ChampionDisarmedException e1) {
				 JOptionPane.showMessageDialog(null, "ChampionDisarmedException");
			} catch (InvalidTargetException e1) {
				 JOptionPane.showMessageDialog(null, "InvalidTargetException");
			}
			View.getP3().removeAll();
			refreshboard();
			View.revalidate();
            View.repaint();
			
		}
///////////////////////////attack right//////////////////////////////////////
		if(b==attackleft){
			try {
				Game.attack(Direction.RIGHT);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
			} catch (ChampionDisarmedException e1) {
				 JOptionPane.showMessageDialog(null, "ChampionDisarmedException");
			} catch (InvalidTargetException e1) {
				 JOptionPane.showMessageDialog(null, "InvalidTargetException");
			}
			View.getP3().removeAll();
			refreshboard();
			View.revalidate();
            View.repaint();
			
		}

///////////////////////////up////////////////////////////////////////////////
		if(b==up){
			try {
				Game.move(Direction.UP);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null, "UnallowedMovementException ");
				
			}
			View.getP3().removeAll();
			refreshboard();
			View.revalidate();
            View.repaint();
		}
///////////////////////////////////down/////////////////////////////////////
		if(b==down){
			try {
				Game.move(Direction.DOWN);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null, "UnallowedMovementException ");
				
			}
			View.getP3().removeAll();
			refreshboard();
		}
////////////////////////////////right/////////////////////////////////////////
		if(b==left){
			try {
				Game.move(Direction.RIGHT);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null, "UnallowedMovementException ");
				
			}
			View.getP3().removeAll();
			refreshboard();
			
		}
////////////////////////////////left//////////////////////////////////////////
		if(b==right){
			try {
				Game.move(Direction.LEFT);
			} catch (NotEnoughResourcesException e1) {
				 JOptionPane.showMessageDialog(null, "NotEnoughResourcesException");
				
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(null, "UnallowedMovementException ");
				
			}
			View.getP3().removeAll();
			refreshboard();
		}
/////////////////////////////Leader ability///////////////////////////////////
		  else if(b==Leaderability1){
			  boolean flag= false;
			  try {
					Game.useLeaderAbility();
				} catch (LeaderNotCurrentException e1) {
					flag= true;
					  JOptionPane.showMessageDialog(null, "the current player is not the leader");
							} catch (LeaderAbilityAlreadyUsedException e1) {
								flag= true;
					 JOptionPane.showMessageDialog(null, "Leader ability already used");
				}
			 
                  if(flag== false){
				  Leaderability1.setBackground(Color.RED);
				  View.revalidate();
	              View.repaint();   }
		  }

		
		  else if(b==Leaderability2){
			  boolean flag= false;
			  
			  try {
					Game.useLeaderAbility();
				} catch (LeaderNotCurrentException e1) {
					flag= true;
					  JOptionPane.showMessageDialog(null, "the current player is not the leader");
							} catch (LeaderAbilityAlreadyUsedException e1) {
								flag= true;
					 JOptionPane.showMessageDialog(null, "Leader ability already used");
				}
			 
                  if(flag== false){
				  Leaderability2.setBackground(Color.RED);
				  View.revalidate();
	              View.repaint();   }
		  }
	

/////////////////////////choosing leader////////////////////////////////
		  else if(counterLeaders<2 && helper(b) &&  counterTeam1>=3 &&
				  counterTeam2>=3){
			
			 if( FPbuttons.contains(b)&& 
					 Game.getFirstPlayer().getLeader()==null){
				 int r= FPbuttons.indexOf(b);
				Champion c= Game.getFirstPlayer().getTeam().get(r);
				Game.getFirstPlayer().setLeader(c);
				b.setBackground(Color.RED);
				counterLeaders++;
			 }

			 else if( SPbuttons.contains(b)&& 
					 Game.getSecondPlayer().getLeader()==null){
				 int r= SPbuttons.indexOf(b);
				Champion c= Game.getSecondPlayer().getTeam().get(r);
				Game.getSecondPlayer().setLeader(c);
				b.setBackground(Color.RED);
				counterLeaders++;
			 }}
/////////////////////////////////////////////////////////////////////////////
			 
			

	
//		else if( counter2 <=2){
//			
//			int r= buttons2.indexOf(b);
//			Champion c= engine.Game.getAvailableChampions().get(r);
//			if(Game.getFirstPlayer().getLeader()==null){
//				Game.getFirstPlayer().setLeader(c);
//				Game.getFirstPlayer().updateleader();
//				counter2++;
//			}
//			if(Game.getSecondPlayer().getLeader()==null){
//				Game.getSecondPlayer().setLeader(c);
//				Game.getSecondPlayer().updateleader();
//				counter2++;
//				
//			}
//			View.remove(View.ِgetP2());
//		}
//	
	

	}
//////////////////////////PQ//////////////////////////////////////////
	public void PQ(){

        
        
     
        View.getP5().add(new JLabel("Turn Order \n"));
        ArrayList<Champion> AL= new ArrayList<Champion>();
        //Game.prepareChampionTurns();
        int size=  Game.getTurnOrder().size();
        for(int i=0; i< size; i++){
      	  Champion c=  (Champion) Game.getTurnOrder().remove();
      	  AL.add(c);
      	 JButton temp=new JButton();
      	  if( c instanceof AntiHero){
      		  temp.setText(c.getName() +", AntiHero");
      	  }
      	 if( c instanceof Hero){
     		  temp.setText(c.getName() +", Hero");
     	  }
      	 if( c instanceof Villain){
     		  temp.setText(c.getName() +", Villain");
     	  }
      	
      	 
      	temp.setToolTipText(c.toString());
      	  View.getP5().add(temp);
      	  TObuttons.add(temp);
      	 View.revalidate();
         View.repaint();
       
      	  
      	 
        }
        int size2= AL.size();
        for(int i=0; i<size2 ; i++){
      	  Champion c=  (Champion) AL.get(i);
      	  Game.getTurnOrder().insert(c);
      	  
      	 
      	System.out.print("yarab " + TObuttons.size());
        }
        View.revalidate();
        View.repaint();
      
      
          }
	
	
/////////////////////////helper///////////////////////////////////////
	public boolean helper(JButton b){
		if((b!=start && b!=Next && b!=Leaderability1 && b!=Leaderability2))
			return true;
		return false;
					
	}
////////////////////////////////////////refresh board////////////////////////////////////////////////////
	public void refreshboard(){
	       for(int x=Game.getBoardheight()-1; x>=0; x--){
         	  for(int y= Game.getBoardwidth()-1; y>=0;y--){
        		
         		  if(Game.getBoard()[x][y]== null){
         			  JButton temp= new JButton();
         			  temp.setBackground(Color.WHITE);
         			  View.getP3().add(temp);
         		  }
         		  else{
         			  if(Game.getBoard()[x][y] instanceof Cover){
         				  Cover c= (Cover)Game.getBoard()[x][y];
         				  JButton temp= new JButton("cover, HP: \n" + c.getCurrentHP());
         				 
         				  temp.setBackground(Color.WHITE);
             			  View.getP3().add(temp);
         			  }
         			  else if(Game.getBoard()[x][y] instanceof Champion){
         				  Champion c= (Champion) Game.getBoard()[x][y];
         				  JButton temp= new JButton(c.getName() +"HP: \n"+ c.getCurrentHP());
         				  temp.setBackground(Color.WHITE);
             			  View.getP3().add(temp);
         			  }
         		  }
         		  
         	  }
         	   View.revalidate();
                View.repaint();
           }
		
	}
////////////////////////////refresh south////////////////////////////
	public void refreshSouth(){
		 String s2 =  View.getName2().getText() +" team: ";
         JLabel t= new JLabel();
         t.setText(s2);
         View.getsPlayer().add(t);
       
         for(int i=0; i<Game.getSecondPlayer().getTeam().size();i++){
         	
      	   Champion c= Game.getSecondPlayer().getTeam().get(i);

      	  JButton temp= new JButton();
      	  if(c== Game.getSecondPlayer().getLeader()){
      		  temp.setBackground(Color.RED);
      	  }
      	 if(c instanceof AntiHero){
   		  temp.setText(c.getName() + " AntiHero");
   	  }
   	  if(c instanceof Hero){
   		  temp.setText(c.getName() + " Hero");
   	  }
   	  if(c instanceof Villain){
   		  temp.setText(c.getName() + " Villain");
   	  }
   	  
     	   View.getsPlayer().add(temp);
     	   temp.setToolTipText(c.toString());
      	  
      	   View.revalidate();
            View.repaint();
        }
		
	}
	
	
////////////////////////////refresh north////////////////////////////
	public void refreshNorth(){
		   String s = View.getName1().getText() +" team: ";
           JLabel t1= new JLabel();
           t1.setText(s);
           View.getfPlayer().add(t1);
           for(int i=0; i<Game.getFirstPlayer().getTeam().size();i++){
           	
        	   Champion c= Game.getFirstPlayer().getTeam().get(i);
        	   JButton temp= new JButton();
        	   if(c== Game.getFirstPlayer().getLeader()){
           		  temp.setBackground(Color.RED);
           	  }
        	  if(c instanceof AntiHero){
        		  temp.setText(c.getName() + " AntiHero");
        	  }
        	  if(c instanceof Hero){
        		  temp.setText(c.getName() + " Hero");
        	  }
        	  if(c instanceof Villain){
        		  temp.setText(c.getName() + " Villain");
        	  }
        	  
        	   View.getfPlayer().add(temp);
        	  temp.setToolTipText(c.toString());
        	  
        	   View.revalidate();
              View.repaint();
          }
         
	}

	
////////////////////////on leader updated////////////////////////////////////

	
	public void OnleaderUpdated() {
		View.remove(View.getP2());
		
		
	}
	@Override
	public void mouseEntered(MouseEvent arg0) {
//		JPanel p= new JPanel();
//		p.add(new JButton("sandy") );
//		View.getP2().add(p);
//		JLabel l= new JLabel();
//		l.setText("sandy");
//		View.getP2().add(l);
		//System.out.print("shaghal ");
	
		
	}

@Override
public void onTeamUpdated() {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseClicked(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}



@Override
public void mouseExited(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mousePressed(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

@Override
public void mouseReleased(MouseEvent arg0) {
	// TODO Auto-generated method stub
	
}

//////////////////////////////////////////////////////////////////////////////	
		
		
	
	
}
