package Gameview;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class View extends JFrame{
	private JPanel P1;
	private JPanel P2;
	private JPanel P3;
	private JPanel P4;
	private JPanel P5;
	

	private JPanel teams;
	private JPanel fPlayer;
	
	private JPanel sPlayer;
    private  JTextField name1;
	private  JTextField name2;
	
	



	public View() {
		// TODO Auto-generated constructor stub
		this.setTitle("Marvel-Game");
		setBounds(50, 50, 800, 600);
		this.setSize(750, 750);
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		///////////////////P1/////////////////////
		P1= new JPanel();
		 name1 = new JTextField(20);
		 name1.setBounds(100,100, 100, 100);
     	 name2 = new JTextField(20);
		 name2.setBounds(5,5, 25, 40);
		
		 JLabel n1= new JLabel("First Player Name");
		 JLabel n2= new JLabel("Second Player Name");
		     P1.add(n1);
		     P1.add(name2);
		     P1.add(n2);
		     P1.add(name1);
		 
		     name1.getText();

		
		this.add(P1, BorderLayout.CENTER);
		P2= new JPanel();
		P3= new JPanel();
		P4= new JPanel();
		P5= new JPanel();
		P5.setPreferredSize(new Dimension(400, getHeight()));
		P5.setLayout(new GridLayout(0, 1));
		teams= new JPanel();
		 fPlayer= new JPanel();
		 sPlayer= new JPanel();
         this.revalidate();
         this.repaint();
	
	}



	
	public JPanel getP5() {
		return P5;
	}


	public JPanel getP1() {
		return P1;
	}


	public JPanel getP2() {
		
		P2.setLayout(new GridLayout(3, 5));
		//add(P2, BorderLayout.CENTER);
		this.add(P2, BorderLayout.CENTER);
		//teams = new JTextArea();
	
		teams.setPreferredSize(new Dimension(400, getHeight()));
		
		//teams.setEditable(false);
		
		teams.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));

		teams.setLayout(new GridLayout(0, 1));
		add(teams, BorderLayout.EAST);
	
		 this.revalidate();
		 this.repaint();
	
		return P2;
	}
	
	public JPanel getTeams() {
		return teams;
	}


	public JPanel getP3() {
		P3.setLayout(new GridLayout(5, 5));

		return P3;
	}
	public JPanel getP4() {
		P4.setLayout(new GridLayout(0,3));
	   
	
		return P4;
	}


	public JTextField getName1() {
		return name1;
	}

	

	public JTextField getName2() {
		return name2;
	}
	public JPanel getfPlayer() {
		
		fPlayer.setLayout(new GridLayout(0,5));
		fPlayer.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 40));
		fPlayer.setPreferredSize(new Dimension(100, 150));
		//fPlayer.setEditable(false);
		
		return fPlayer;
	}

	

	public JPanel getsPlayer() {
		sPlayer.setLayout(new GridLayout(0,5));
		sPlayer.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 40));
		sPlayer.setPreferredSize(new Dimension(100, 150));
		//sPlayer.setEditable(false);
		

		return sPlayer;
	}




	
	

}
